
package parcial;

public enum TipoPreparacion {
    FRIO,CALIENTE
}
