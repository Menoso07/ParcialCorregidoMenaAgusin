package parcial;

public interface Preparacion {
    void preparar();
}
