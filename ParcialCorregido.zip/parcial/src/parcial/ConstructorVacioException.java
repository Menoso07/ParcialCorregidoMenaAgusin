package parcial;

public class ConstructorVacioException extends RuntimeException{

    public ConstructorVacioException() {
    }

    public ConstructorVacioException(String message) {
        super(message);
    }
    
    
    
}
