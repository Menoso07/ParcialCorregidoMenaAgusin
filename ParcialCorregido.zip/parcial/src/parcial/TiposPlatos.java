package parcial;

public enum TiposPlatos {
    ENTRADA,PLATOPRINCIPAL,POSTRE
}
