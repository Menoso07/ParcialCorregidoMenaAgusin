package parcial;

public interface Decoracion {
    void decorar();
}


